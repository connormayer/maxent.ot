library(testthat)
library(maxent.ot)

test_check("maxent.ot")
